default_app_config = 'django_tenants.apps.DjangoTenantsConfig'
