from django_tenants.management.commands.migrate_schemas import MigrateSchemasCommand


Command = MigrateSchemasCommand
