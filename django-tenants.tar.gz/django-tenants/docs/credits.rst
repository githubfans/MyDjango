=======
Credits
=======

django-tenant-schemas
---------------------

I would like to thank the original author of this project Bernardo Pires Carneiro under the name `django-tenant-schemas <https://github.com/bernardopires/django-tenant-schemas>`_. I forked this project as I wanted to add enhancements to make it work better with Django 1.8

If you are using Django 1.7 or below please use his project.
