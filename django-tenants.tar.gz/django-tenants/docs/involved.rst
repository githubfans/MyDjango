=============
Get Involved!
=============
Suggestions, bugs, ideas, patches, questions
--------------------------------------------
Are **highly** welcome! Feel free to write an issue for any feedback you have or send a pull request on `GitHub <https://github.com/tomturner/django-tenants>`. :)
