from django.apps import AppConfig


class BarangConfig(AppConfig):
    name = 'barang'
