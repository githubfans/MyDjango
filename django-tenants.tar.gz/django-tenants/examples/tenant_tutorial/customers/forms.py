from django import forms


class GenerateUsersForm(forms.Form):
    pass
