from django.apps import AppConfig


class TenantOnlyConfig(AppConfig):
    name = 'tenant_only'
